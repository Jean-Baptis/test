export const Z_INDEX = {
  LOGO: 3000,
  RIGHT_PANEL: 1
};
