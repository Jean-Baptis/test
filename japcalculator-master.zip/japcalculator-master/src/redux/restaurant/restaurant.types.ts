export interface Restaurant {
  id: string;
  name: string;
  address: string;
  longitude: number;
  latitude: number;
}
